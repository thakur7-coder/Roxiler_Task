import Dashboard from './pages/Dashboard/Dashboard';


function App() {
  return (
    <div className="container">
      <Dashboard />
    </div>
  );
}

export default App;
